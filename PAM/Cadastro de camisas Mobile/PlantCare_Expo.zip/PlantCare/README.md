# PlantCare 🌱

Aplicativo mobile de cuidado com plantas desenvolvido com React Native e Expo.

## Funcionalidades

- Cadastro, edição e exclusão de plantas.
- Foto da planta usando a câmera ou escolhendo uma imagem da galeria.
- Definição do intervalo entre regas.
- Registro da rega e indicação de plantas que precisam de água.
- Notificações locais de teste.
- Busca e filtros no jardim.
- Persistência local dos dados usando AsyncStorage.
- Interface adaptada para celular.

## Requisitos

- Node.js LTS
- Expo Go instalado no celular (para desenvolvimento)
- Android ou iOS para testar câmera e notificações

## Como executar

1. Extraia o arquivo ZIP.
2. Abra o terminal na pasta `PlantCare`.
3. Execute:

```bash
npm install
npx expo start
```

4. Instale o Expo Go no celular.
5. Escaneie o QR Code exibido no terminal ou no navegador.

Se estiver usando Windows e o QR Code não conectar, deixe o computador e o celular na mesma rede Wi-Fi. Como alternativa, execute `npx expo start --tunnel`.

## Como testar os recursos nativos

### Câmera e galeria
- Toque em `+` para cadastrar uma planta.
- Toque em `Adicionar foto da planta`.
- Escolha `Tirar foto` ou `Escolher da galeria`.
- Conceda a permissão solicitada pelo sistema.

### Notificações locais
- Ao cadastrar uma planta com `Lembrete de cuidado` ligado, o aplicativo solicitará permissão e programará uma notificação de teste para cerca de 1 minuto depois.
- Na aba `Cuidados`, também é possível tocar em `Testar lembrete`.
- Para receber o aviso, permita notificações nas configurações do aparelho.

**Importante:** o lembrete implementado é de demonstração, disparado cerca de um minuto após a programação. Ele não cria automaticamente notificações recorrentes nos dias de rega. A frequência cadastrada é usada para calcular o estado da planta dentro do aplicativo.

## Observações técnicas

- Os dados ficam no dispositivo por meio do AsyncStorage.
- As plantas iniciais são exemplos para demonstrar a interface. Ao salvar alterações, os dados são gravados localmente.
- A indicação de rega é uma estimativa baseada no intervalo configurado. As necessidades reais variam conforme espécie, iluminação, temperatura, estação e umidade do solo.
- A câmera e as notificações devem ser testadas em um aparelho físico para validar as permissões e o comportamento do sistema.
- Para uma versão de produção, recomenda-se configurar um ícone de notificação próprio e testar a compilação nativa.

## Requisitos do professor atendidos

| Requisito | Implementação |
|---|---|
| Câmera / imagens | `expo-image-picker` permite fotografar plantas |
| Galeria de fotos | `expo-image-picker` permite selecionar imagens |
| Notificações locais | `expo-notifications` agenda aviso no aparelho |
| Aplicação mobile | React Native com Expo |
