import React, { useEffect, useMemo, useState } from "react";
import {
  Alert, Image, KeyboardAvoidingView, Modal, Platform, Pressable,
  SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput,
  View, Switch
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";
import * as Notifications from "expo-notifications";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true
  })
});

const GREEN = "#2E6B45";
const DARK = "#1D3326";
const MINT = "#E7F1E5";
const BG = "#F5F7F2";
const MUTED = "#758276";
const STORAGE_KEY = "@plantcare/plants-v1";

const starterPlants = [
  { id: "demo-1", name: "Jiboia", species: "Epipremnum aureum", location: "Sala", frequency: 3, lastWatered: null, photo: null, reminder: true },
  { id: "demo-2", name: "Espada-de-são-jorge", species: "Dracaena trifasciata", location: "Quarto", frequency: 10, lastWatered: null, photo: null, reminder: false },
  { id: "demo-3", name: "Manjericão", species: "Ocimum basilicum", location: "Cozinha", frequency: 2, lastWatered: null, photo: null, reminder: true }
];

function daysSince(date) {
  if (!date) return 999;
  return Math.floor((Date.now() - new Date(date).getTime()) / 86400000);
}
function needsWater(plant) {
  return !plant.lastWatered || daysSince(plant.lastWatered) >= Number(plant.frequency || 3);
}
function nextWaterLabel(plant) {
  if (!plant.lastWatered) return "Registre a primeira rega";
  const remaining = Number(plant.frequency || 3) - daysSince(plant.lastWatered);
  if (remaining <= 0) return "Precisa de água";
  if (remaining === 1) return "Regar amanhã";
  return `Regar em ${remaining} dias`;
}
function dateLabel(date) {
  if (!date) return "Ainda não regada";
  return new Date(date).toLocaleDateString("pt-BR");
}

function PlantIcon({ size = 30, color = GREEN }) {
  return <Text style={{ fontSize: size, color, lineHeight: size + 4 }}>✿</Text>;
}
function Button({ title, onPress, secondary = false, style }) {
  return (
    <Pressable onPress={onPress} style={[styles.button, secondary && styles.buttonSecondary, style]}>
      <Text style={[styles.buttonText, secondary && styles.buttonSecondaryText]}>{title}</Text>
    </Pressable>
  );
}
function Chip({ children, active = false }) {
  return <View style={[styles.chip, active && styles.chipActive]}><Text style={[styles.chipText, active && styles.chipTextActive]}>{children}</Text></View>;
}

export default function App() {
  const [plants, setPlants] = useState(starterPlants);
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState("home");
  const [modalVisible, setModalVisible] = useState(false);
  const [editingPlant, setEditingPlant] = useState(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("Todas");
  const [form, setForm] = useState({ name: "", species: "", location: "", frequency: "3", photo: null, reminder: true });
  const [permissionGranted, setPermissionGranted] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        if (saved) setPlants(JSON.parse(saved));
      } catch (e) {
        console.warn("Não foi possível carregar os dados salvos.", e);
      } finally {
        setLoaded(true);
      }
      try {
        if (Platform.OS !== "web") {
          const { status } = await Notifications.requestPermissionsAsync();
          setPermissionGranted(status === "granted");
          if (Platform.OS === "android") {
            await Notifications.setNotificationChannelAsync("plant-reminders", {
              name: "Lembretes de plantas",
              importance: Notifications.AndroidImportance.HIGH,
              vibrationPattern: [0, 250, 250, 250],
              lightColor: GREEN
            });
          }
        }
      } catch (e) {
        console.warn("Permissão de notificações indisponível.", e);
      }
    })();
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(plants)).catch(console.warn);
  }, [plants, loaded]);

  const duePlants = useMemo(() => plants.filter(needsWater), [plants]);
  const filteredPlants = useMemo(() => plants.filter(p => {
    const matchesQuery = `${p.name} ${p.species || ""} ${p.location || ""}`.toLowerCase().includes(query.toLowerCase());
    const matchesFilter = filter === "Todas" || (filter === "Precisam de água" ? needsWater(p) : !needsWater(p));
    return matchesQuery && matchesFilter;
  }), [plants, query, filter]);

  function updateForm(key, value) { setForm(prev => ({ ...prev, [key]: value })); }
  function openNewPlant() {
    setEditingPlant(null);
    setForm({ name: "", species: "", location: "", frequency: "3", photo: null, reminder: true });
    setModalVisible(true);
  }
  function openEditPlant(plant) {
    setEditingPlant(plant);
    setForm({ name: plant.name, species: plant.species || "", location: plant.location || "", frequency: String(plant.frequency || 3), photo: plant.photo || null, reminder: !!plant.reminder });
    setModalVisible(true);
  }
  async function choosePhoto(source) {
    try {
      if (source === "camera") {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) {
          Alert.alert("Permissão necessária", "Permita o acesso à câmera nas configurações do aparelho.");
          return;
        }
        const result = await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: [4, 3], quality: 0.75 });
        if (!result.canceled) updateForm("photo", result.assets[0].uri);
      } else {
        const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!permission.granted) {
          Alert.alert("Permissão necessária", "Permita o acesso à galeria para escolher uma foto.");
          return;
        }
        const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: [4, 3], quality: 0.75 });
        if (!result.canceled) updateForm("photo", result.assets[0].uri);
      }
    } catch (e) {
      Alert.alert("Não foi possível abrir as imagens", "Tente novamente no celular.");
    }
  }
  async function scheduleReminder(plant) {
    if (Platform.OS === "web") {
      Alert.alert("Disponível no celular", "As notificações locais precisam ser testadas no Android ou iOS.");
      return;
    }
    try {
      const { status } = await Notifications.getPermissionsAsync();
      if (status !== "granted") {
        const result = await Notifications.requestPermissionsAsync();
        if (result.status !== "granted") {
          Alert.alert("Notificações desativadas", "Ative as notificações do PlantCare nas configurações do aparelho.");
          return;
        }
      }
      const triggerDate = new Date(Date.now() + 60 * 1000);
      await Notifications.scheduleNotificationAsync({
        content: {
          title: `Hora de cuidar da ${plant.name} 🌱`,
          body: `Confira se sua planta precisa de água. Frequência cadastrada: a cada ${plant.frequency} dia(s).`,
          sound: true,
          data: { plantId: plant.id },
          ...(Platform.OS === "android" ? { channelId: "plant-reminders" } : {})
        },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: triggerDate }
      });
      Alert.alert("Lembrete programado", `Você receberá uma notificação de teste em cerca de 1 minuto para ${plant.name}.`);
    } catch (e) {
      Alert.alert("Erro ao programar", "Não foi possível programar o lembrete neste aparelho.");
    }
  }
  async function savePlant() {
    if (!form.name.trim()) {
      Alert.alert("Falta o nome", "Digite o nome da planta para continuar.");
      return;
    }
    const frequency = Math.max(1, Math.min(60, parseInt(form.frequency, 10) || 3));
    const plant = {
      id: editingPlant?.id || `plant-${Date.now()}`,
      name: form.name.trim(),
      species: form.species.trim(),
      location: form.location.trim(),
      frequency,
      lastWatered: editingPlant?.lastWatered || null,
      photo: form.photo,
      reminder: form.reminder
    };
    setPlants(prev => editingPlant ? prev.map(p => p.id === plant.id ? plant : p) : [plant, ...prev]);
    setModalVisible(false);
    if (plant.reminder) scheduleReminder(plant);
  }
  function waterPlant(plant) {
    const now = new Date().toISOString();
    setPlants(prev => prev.map(p => p.id === plant.id ? { ...p, lastWatered: now } : p));
    Alert.alert("Rega registrada! 💧", `O cuidado com ${plant.name} foi registrado em ${new Date(now).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}.`);
  }
  function deletePlant(plant) {
    Alert.alert("Excluir planta", `Deseja remover ${plant.name} do seu jardim?`, [
      { text: "Cancelar", style: "cancel" },
      { text: "Excluir", style: "destructive", onPress: () => setPlants(prev => prev.filter(p => p.id !== plant.id)) }
    ]);
  }

  function PlantCard({ plant }) {
    const due = needsWater(plant);
    return (
      <View style={styles.plantCard}>
        <Pressable onPress={() => openEditPlant(plant)} style={styles.plantPhotoWrap}>
          {plant.photo ? <Image source={{ uri: plant.photo }} style={styles.plantPhoto} /> : <View style={styles.photoPlaceholder}><PlantIcon size={35}/></View>}
        </Pressable>
        <View style={styles.plantInfo}>
          <Text style={styles.plantName}>{plant.name}</Text>
          <Text style={styles.plantSpecies} numberOfLines={1}>{plant.species || "Espécie não informada"}</Text>
          <Text style={styles.plantLocation}>⌖  {plant.location || "Local não informado"}</Text>
          <View style={{ alignSelf: "flex-start", marginTop: 7 }}>
            <Chip active={due}>{due ? "Precisa de água" : nextWaterLabel(plant)}</Chip>
          </View>
        </View>
        <Pressable onPress={() => waterPlant(plant)} style={styles.waterButton}>
          <Text style={styles.waterIcon}>💧</Text>
          <Text style={styles.waterText}>Regar</Text>
        </Pressable>
        <Pressable onPress={() => deletePlant(plant)} style={styles.deleteButton}><Text style={styles.deleteText}>×</Text></Pressable>
      </View>
    );
  }

  function Header() {
    return (
      <View style={styles.header}>
        <View style={styles.brandMark}><PlantIcon size={25} color="#FFFFFF"/></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.brand}>PlantCare</Text>
          <Text style={styles.brandSub}>seu jardim, mais saudável</Text>
        </View>
        <Pressable onPress={openNewPlant} style={styles.addHeader}><Text style={styles.addHeaderText}>＋</Text></Pressable>
      </View>
    );
  }

  function HomeScreen() {
    return (
      <>
        <View style={styles.hero}>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>SEU JARDIM EM UM SÓ LUGAR</Text>
            <Text style={styles.heroTitle}>Pequenos cuidados,{`\n`}grandes crescimentos.</Text>
            <Text style={styles.heroCopy}>Um lembrete de cada vez, suas plantas florescem.</Text>
            <Button title="+ Adicionar planta" onPress={openNewPlant} style={{ alignSelf: "flex-start", marginTop: 16 }} />
          </View>
          <View style={styles.heroPlant}><Text style={{ fontSize: 67 }}>🪴</Text></View>
        </View>
        <View style={styles.statsRow}>
          <View style={styles.statCard}><Text style={styles.statIcon}>🌿</Text><Text style={styles.statNumber}>{plants.length}</Text><Text style={styles.statLabel}>No jardim</Text></View>
          <View style={styles.statCard}><Text style={styles.statIcon}>💧</Text><Text style={styles.statNumber}>{duePlants.length}</Text><Text style={styles.statLabel}>Precisam de água</Text></View>
          <View style={styles.statCard}><Text style={styles.statIcon}>✓</Text><Text style={styles.statNumber}>{plants.length - duePlants.length}</Text><Text style={styles.statLabel}>Em dia</Text></View>
        </View>
        <View style={styles.sectionHeading}>
          <View><Text style={styles.sectionTitle}>Precisam de atenção</Text><Text style={styles.sectionSub}>Cuide delas hoje</Text></View>
          <Pressable onPress={() => { setTab("plants"); setFilter("Precisam de água"); }}><Text style={styles.linkText}>Ver todas →</Text></Pressable>
        </View>
        {duePlants.length ? duePlants.slice(0, 3).map(p => <PlantCard key={p.id} plant={p} />) : (
          <View style={styles.emptyCard}><Text style={{ fontSize: 30 }}>🌼</Text><Text style={styles.emptyTitle}>Tudo em dia!</Text><Text style={styles.emptyCopy}>Seu jardim está bem cuidado. Volte amanhã para conferir.</Text></View>
        )}
        <View style={styles.tipCard}><Text style={styles.tipIcon}>☀️</Text><View style={{ flex: 1 }}><Text style={styles.tipTitle}>Dica verde</Text><Text style={styles.tipCopy}>Antes de regar, toque a terra. Algumas plantas preferem secar um pouco entre as regas.</Text></View></View>
      </>
    );
  }

  function PlantsScreen() {
    return (
      <>
        <Text style={styles.screenTitle}>Meu jardim 🌱</Text>
        <Text style={styles.screenSubtitle}>Todas as suas plantas em um só lugar.</Text>
        <TextInput value={query} onChangeText={setQuery} placeholder="⌕  Buscar planta ou local..." placeholderTextColor="#8B978B" style={styles.searchInput} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, marginBottom: 14 }}>
          {["Todas", "Precisam de água", "Em dia"].map(f => <Pressable key={f} onPress={() => setFilter(f)} style={{ marginRight: 8 }}><Chip active={filter === f}>{f}</Chip></Pressable>)}
        </ScrollView>
        {filteredPlants.length ? filteredPlants.map(p => <PlantCard key={p.id} plant={p} />) : (
          <View style={styles.emptyCard}><Text style={{ fontSize: 30 }}>🔎</Text><Text style={styles.emptyTitle}>Nenhuma planta encontrada</Text><Text style={styles.emptyCopy}>Tente outra busca ou adicione uma nova planta.</Text><Button title="Adicionar planta" onPress={openNewPlant} /></View>
        )}
        <Button title="+ Cadastrar nova planta" onPress={openNewPlant} style={{ marginTop: 8 }} />
      </>
    );
  }

  function CareScreen() {
    return (
      <>
        <Text style={styles.screenTitle}>Rotina de cuidados</Text>
        <Text style={styles.screenSubtitle}>Registre a rega e configure lembretes.</Text>
        <View style={styles.reminderBanner}><Text style={{ fontSize: 28 }}>🔔</Text><View style={{ flex: 1 }}><Text style={styles.tipTitle}>Notificações locais</Text><Text style={styles.tipCopy}>{permissionGranted ? "Permissão concedida. Você pode testar um lembrete em cada planta." : "Ao ativar um lembrete, o app solicitará permissão para notificar."}</Text></View></View>
        {plants.map(plant => (
          <View key={plant.id} style={styles.careCard}>
            <View style={styles.careTop}>
              {plant.photo ? <Image source={{ uri: plant.photo }} style={styles.carePhoto} /> : <View style={styles.carePhotoPlaceholder}><PlantIcon size={25}/></View>}
              <View style={{ flex: 1 }}><Text style={styles.plantName}>{plant.name}</Text><Text style={styles.plantSpecies}>Última rega: {dateLabel(plant.lastWatered)}</Text></View>
              <Chip active={needsWater(plant)}>{needsWater(plant) ? "Pendente" : "Em dia"}</Chip>
            </View>
            <View style={styles.careDetails}><Text style={styles.careDetailText}>Frequência: a cada {plant.frequency} dia(s)</Text><Text style={styles.careDetailText}>{nextWaterLabel(plant)}</Text></View>
            <View style={styles.careActions}><Button title="💧 Registrar rega" onPress={() => waterPlant(plant)} style={{ flex: 1 }} /><Button title="Testar lembrete" secondary onPress={() => scheduleReminder(plant)} style={{ flex: 1 }} /></View>
          </View>
        ))}
      </>
    );
  }

  function ProfileScreen() {
    return (
      <>
        <Text style={styles.screenTitle}>Sobre o PlantCare</Text>
        <Text style={styles.screenSubtitle}>Tecnologia para cultivar hábitos mais verdes.</Text>
        <View style={styles.profileHero}><Text style={{ fontSize: 58 }}>🌱</Text><Text style={styles.profileTitle}>Cada planta importa.</Text><Text style={styles.profileCopy}>O PlantCare ajuda você a organizar seu jardim, registrar o crescimento e lembrar dos cuidados essenciais.</Text></View>
        <Text style={styles.sectionTitle}>Recursos do aplicativo</Text>
        {[
          ["📸", "Câmera e galeria", "Adicione uma foto real para identificar visualmente cada planta."],
          ["🔔", "Notificações locais", "Programe um lembrete de teste e receba o aviso no próprio aparelho."],
          ["💾", "Salvamento local", "Suas plantas ficam salvas no dispositivo mesmo após fechar o aplicativo."],
          ["💧", "Histórico de regas", "Registre a última rega e acompanhe quais plantas precisam de atenção."]
        ].map(([icon, title, body]) => <View key={title} style={styles.featureRow}><View style={styles.featureIcon}><Text style={{ fontSize: 22 }}>{icon}</Text></View><View style={{ flex: 1 }}><Text style={styles.featureTitle}>{title}</Text><Text style={styles.featureCopy}>{body}</Text></View></View>)}
        <View style={styles.aboutFoot}><Text style={styles.aboutFootText}>Projeto acadêmico • React Native + Expo</Text><Text style={styles.aboutFootText}>PlantCare © 2026</Text></View>
      </>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ExpoStatusBar style="dark" />
      <StatusBar barStyle="dark-content" backgroundColor={BG} />
      <Header />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {tab === "home" && <HomeScreen />}
        {tab === "plants" && <PlantsScreen />}
        {tab === "care" && <CareScreen />}
        {tab === "profile" && <ProfileScreen />}
        <View style={{ height: 24 }} />
      </ScrollView>
      <View style={styles.tabBar}>
        {[
          ["home", "⌂", "Início"],
          ["plants", "♧", "Meu jardim"],
          ["care", "◷", "Cuidados"],
          ["profile", "☻", "Sobre"]
        ].map(([key, icon, label]) => (
          <Pressable key={key} onPress={() => setTab(key)} style={styles.tabItem}>
            <View style={[styles.tabIconWrap, tab === key && styles.tabIconWrapActive]}><Text style={[styles.tabIcon, tab === key && styles.tabIconActive]}>{icon}</Text></View>
            <Text style={[styles.tabLabel, tab === key && styles.tabLabelActive]}>{label}</Text>
          </Pressable>
        ))}
      </View>

      <Modal visible={modalVisible} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setModalVisible(false)}>
        <SafeAreaView style={styles.modalSafe}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
            <View style={styles.modalHeader}><Pressable onPress={() => setModalVisible(false)}><Text style={styles.cancelText}>Cancelar</Text></Pressable><Text style={styles.modalTitle}>{editingPlant ? "Editar planta" : "Nova planta"}</Text><Pressable onPress={savePlant}><Text style={styles.saveText}>Salvar</Text></Pressable></View>
            <ScrollView contentContainerStyle={styles.modalContent} keyboardShouldPersistTaps="handled">
              <Pressable style={styles.photoPicker} onPress={() => Alert.alert("Adicionar foto", "Escolha de onde vem a imagem.", [{ text: "Cancelar", style: "cancel" }, { text: "Tirar foto", onPress: () => choosePhoto("camera") }, { text: "Escolher da galeria", onPress: () => choosePhoto("gallery") }])}>
                {form.photo ? <Image source={{ uri: form.photo }} style={styles.selectedPhoto} /> : <><View style={styles.photoPickerIcon}><Text style={{ fontSize: 30 }}>📷</Text></View><Text style={styles.photoPickerTitle}>Adicionar foto da planta</Text><Text style={styles.photoPickerSub}>Use a câmera ou escolha na galeria</Text></>}
              </Pressable>
              <Text style={styles.fieldLabel}>Nome da planta *</Text>
              <TextInput value={form.name} onChangeText={v => updateForm("name", v)} placeholder="Ex.: Costela-de-adão" placeholderTextColor="#9AA59A" style={styles.fieldInput} />
              <Text style={styles.fieldLabel}>Espécie (opcional)</Text>
              <TextInput value={form.species} onChangeText={v => updateForm("species", v)} placeholder="Ex.: Monstera deliciosa" placeholderTextColor="#9AA59A" style={styles.fieldInput} />
              <Text style={styles.fieldLabel}>Onde ela fica?</Text>
              <TextInput value={form.location} onChangeText={v => updateForm("location", v)} placeholder="Ex.: Varanda, sala, jardim..." placeholderTextColor="#9AA59A" style={styles.fieldInput} />
              <Text style={styles.fieldLabel}>Intervalo entre regas (dias)</Text>
              <TextInput value={form.frequency} onChangeText={v => updateForm("frequency", v.replace(/[^0-9]/g, ""))} keyboardType="number-pad" placeholder="3" placeholderTextColor="#9AA59A" style={styles.fieldInput} />
              <View style={styles.switchRow}><View style={{ flex: 1 }}><Text style={styles.fieldLabel}>Lembrete de cuidado</Text><Text style={styles.switchSub}>Agendar um aviso de teste após salvar.</Text></View><Switch value={form.reminder} onValueChange={v => updateForm("reminder", v)} trackColor={{ false: "#D9E0D6", true: "#A7C8A7" }} thumbColor={form.reminder ? GREEN : "#F4F4F4"} /></View>
              <Text style={styles.formNote}>* O intervalo é uma referência configurada por você. A necessidade real de água depende da espécie, da luz, da temperatura e da umidade do solo.</Text>
              <Button title={editingPlant ? "Salvar alterações" : "Adicionar ao meu jardim"} onPress={savePlant} style={{ marginTop: 18, paddingVertical: 16 }} />
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingTop: Platform.OS === "android" ? 12 : 5, paddingBottom: 13, backgroundColor: BG },
  brandMark: { width: 42, height: 42, borderRadius: 15, backgroundColor: GREEN, alignItems: "center", justifyContent: "center", marginRight: 11 },
  brand: { color: DARK, fontSize: 20, fontWeight: "800", letterSpacing: -0.5 },
  brandSub: { color: MUTED, fontSize: 11, marginTop: 1 },
  addHeader: { width: 40, height: 40, borderRadius: 14, backgroundColor: MINT, alignItems: "center", justifyContent: "center" },
  addHeaderText: { color: GREEN, fontSize: 27, lineHeight: 30, fontWeight: "400" },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 18, paddingTop: 7 },
  hero: { backgroundColor: "#E7F0E2", borderRadius: 26, padding: 21, minHeight: 222, flexDirection: "row", overflow: "hidden" },
  eyebrow: { color: GREEN, fontSize: 9, fontWeight: "800", letterSpacing: 1.1, marginBottom: 10 },
  heroTitle: { color: DARK, fontSize: 24, lineHeight: 29, fontWeight: "800", letterSpacing: -0.7 },
  heroCopy: { color: "#5E7462", fontSize: 12, lineHeight: 18, marginTop: 8, maxWidth: 220 },
  heroPlant: { position: "absolute", right: 7, bottom: 14, opacity: 0.92 },
  button: { backgroundColor: GREEN, borderRadius: 13, paddingHorizontal: 16, paddingVertical: 12, alignItems: "center", justifyContent: "center", flexDirection: "row" },
  buttonText: { color: "#FFFFFF", fontWeight: "700", fontSize: 12 },
  buttonSecondary: { backgroundColor: "#EEF3EB", borderWidth: 1, borderColor: "#DDE7DA" },
  buttonSecondaryText: { color: GREEN },
  statsRow: { flexDirection: "row", gap: 9, marginTop: 14, marginBottom: 25 },
  statCard: { flex: 1, backgroundColor: "#FFFFFF", borderRadius: 17, paddingVertical: 13, paddingHorizontal: 11, borderWidth: 1, borderColor: "#EBEFE7" },
  statIcon: { fontSize: 16, marginBottom: 5 },
  statNumber: { color: DARK, fontSize: 22, fontWeight: "800" },
  statLabel: { color: MUTED, fontSize: 10, marginTop: 3 },
  sectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  sectionTitle: { color: DARK, fontSize: 17, fontWeight: "800", letterSpacing: -0.3 },
  sectionSub: { color: MUTED, fontSize: 11, marginTop: 3 },
  linkText: { color: GREEN, fontSize: 12, fontWeight: "700" },
  plantCard: { backgroundColor: "#FFFFFF", borderRadius: 18, padding: 11, flexDirection: "row", alignItems: "center", marginBottom: 10, borderWidth: 1, borderColor: "#E9EEE5", minHeight: 115 },
  plantPhotoWrap: { width: 75, height: 85, borderRadius: 14, overflow: "hidden", marginRight: 12 },
  plantPhoto: { width: "100%", height: "100%", backgroundColor: MINT },
  photoPlaceholder: { flex: 1, backgroundColor: "#E9F1E5", alignItems: "center", justifyContent: "center" },
  plantInfo: { flex: 1, minWidth: 0 },
  plantName: { color: DARK, fontSize: 13, fontWeight: "800" },
  plantSpecies: { color: MUTED, fontSize: 10, marginTop: 3 },
  plantLocation: { color: "#6E7F70", fontSize: 10, marginTop: 6 },
  chip: { backgroundColor: "#EFF2ED", paddingHorizontal: 9, paddingVertical: 5, borderRadius: 9 },
  chipActive: { backgroundColor: "#FFF0D9" },
  chipText: { color: "#68766A", fontSize: 9, fontWeight: "700" },
  chipTextActive: { color: "#A56519" },
  waterButton: { alignItems: "center", justifyContent: "center", backgroundColor: MINT, borderRadius: 12, width: 48, height: 56, marginLeft: 5 },
  waterIcon: { fontSize: 17 },
  waterText: { color: GREEN, fontSize: 9, fontWeight: "800", marginTop: 3 },
  deleteButton: { position: "absolute", right: 7, top: 4, width: 19, height: 19, alignItems: "center", justifyContent: "center" },
  deleteText: { color: "#A1ABA0", fontSize: 17, lineHeight: 18 },
  emptyCard: { backgroundColor: "#FFFFFF", borderRadius: 20, padding: 25, alignItems: "center", borderWidth: 1, borderColor: "#E9EEE5", marginBottom: 13 },
  emptyTitle: { color: DARK, fontWeight: "800", fontSize: 16, marginTop: 8 },
  emptyCopy: { color: MUTED, textAlign: "center", fontSize: 12, lineHeight: 18, marginTop: 6, marginBottom: 15 },
  tipCard: { backgroundColor: "#F0F3E6", borderRadius: 17, padding: 15, flexDirection: "row", alignItems: "flex-start", gap: 12, marginTop: 7 },
  tipIcon: { fontSize: 24 },
  tipTitle: { color: DARK, fontSize: 12, fontWeight: "800" },
  tipCopy: { color: "#657666", fontSize: 11, lineHeight: 17, marginTop: 4 },
  screenTitle: { color: DARK, fontSize: 26, fontWeight: "800", letterSpacing: -0.8, marginTop: 9 },
  screenSubtitle: { color: MUTED, fontSize: 12, lineHeight: 18, marginTop: 5, marginBottom: 20 },
  searchInput: { height: 47, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E4EAE0", paddingHorizontal: 15, color: DARK, marginBottom: 13, fontSize: 12 },
  tabBar: { flexDirection: "row", backgroundColor: "#FFFFFF", paddingTop: 9, paddingBottom: Platform.OS === "ios" ? 22 : 9, borderTopWidth: 1, borderTopColor: "#E8EDE5", justifyContent: "space-around" },
  tabItem: { flex: 1, alignItems: "center", justifyContent: "center" },
  tabIconWrap: { width: 42, height: 30, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  tabIconWrapActive: { backgroundColor: MINT },
  tabIcon: { fontSize: 22, color: "#849184", lineHeight: 25 },
  tabIconActive: { color: GREEN },
  tabLabel: { color: "#899589", fontSize: 9, marginTop: 2 },
  tabLabelActive: { color: GREEN, fontWeight: "800" },
  reminderBanner: { flexDirection: "row", alignItems: "center", gap: 12, padding: 16, backgroundColor: "#E8F1E5", borderRadius: 17, marginBottom: 15 },
  careCard: { backgroundColor: "#FFFFFF", borderRadius: 18, padding: 13, marginBottom: 12, borderWidth: 1, borderColor: "#E9EEE5" },
  careTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  carePhoto: { width: 45, height: 45, borderRadius: 13 },
  carePhotoPlaceholder: { width: 45, height: 45, borderRadius: 13, backgroundColor: MINT, alignItems: "center", justifyContent: "center" },
  careDetails: { marginTop: 13, paddingTop: 11, borderTopWidth: 1, borderTopColor: "#EFF2EC", gap: 5 },
  careDetailText: { color: MUTED, fontSize: 11 },
  careActions: { flexDirection: "row", gap: 8, marginTop: 12 },
  profileHero: { backgroundColor: "#E7F0E2", borderRadius: 23, padding: 24, alignItems: "center", marginBottom: 25 },
  profileTitle: { color: DARK, fontSize: 21, fontWeight: "800", marginTop: 9 },
  profileCopy: { color: "#617565", fontSize: 12, textAlign: "center", lineHeight: 19, marginTop: 8 },
  featureRow: { flexDirection: "row", gap: 13, alignItems: "center", paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: "#E5EBE1" },
  featureIcon: { width: 48, height: 48, borderRadius: 15, backgroundColor: "#E8F1E5", alignItems: "center", justifyContent: "center" },
  featureTitle: { color: DARK, fontSize: 13, fontWeight: "800" },
  featureCopy: { color: MUTED, fontSize: 11, lineHeight: 17, marginTop: 3 },
  aboutFoot: { alignItems: "center", paddingVertical: 22, gap: 5 },
  aboutFootText: { color: "#8B978B", fontSize: 10 },
  modalSafe: { flex: 1, backgroundColor: BG },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 20, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: "#E5EBE1" },
  modalTitle: { color: DARK, fontWeight: "800", fontSize: 16 },
  cancelText: { color: MUTED, fontSize: 13 },
  saveText: { color: GREEN, fontSize: 13, fontWeight: "800" },
  modalContent: { padding: 20, paddingBottom: 35 },
  photoPicker: { height: 160, borderRadius: 20, backgroundColor: "#E8F1E5", alignItems: "center", justifyContent: "center", marginBottom: 22, overflow: "hidden", borderWidth: 1, borderColor: "#D9E7D4", borderStyle: "dashed" },
  photoPickerIcon: { width: 55, height: 55, borderRadius: 18, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", marginBottom: 8 },
  photoPickerTitle: { color: DARK, fontSize: 13, fontWeight: "800" },
  photoPickerSub: { color: MUTED, fontSize: 10, marginTop: 4 },
  selectedPhoto: { width: "100%", height: "100%" },
  fieldLabel: { color: DARK, fontSize: 12, fontWeight: "800", marginBottom: 8, marginTop: 10 },
  fieldInput: { backgroundColor: "#FFFFFF", borderRadius: 13, borderWidth: 1, borderColor: "#E1E8DD", height: 48, paddingHorizontal: 14, color: DARK, fontSize: 13 },
  switchRow: { flexDirection: "row", alignItems: "center", marginTop: 17, paddingVertical: 8 },
  switchSub: { color: MUTED, fontSize: 10, marginTop: 2 },
  formNote: { color: "#879287", fontSize: 10, lineHeight: 16, marginTop: 14 }
});